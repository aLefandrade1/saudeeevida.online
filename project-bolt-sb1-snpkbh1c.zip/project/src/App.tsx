import React, { useState } from 'react';
import type { FormData } from './types';
import RecipeForm from './components/RecipeForm';
import PersonalizedRecipe from './components/PersonalizedRecipe';

function App() {
  const [formData, setFormData] = useState<FormData | null>(null);

  const handleSubmit = (data: FormData) => {
    setFormData(data);
  };

  const handleReset = () => {
    setFormData(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {!formData ? (
        <RecipeForm onSubmit={handleSubmit} />
      ) : (
        <PersonalizedRecipe data={formData} onReset={handleReset} />
      )}
    </div>
  );
}

export default App;