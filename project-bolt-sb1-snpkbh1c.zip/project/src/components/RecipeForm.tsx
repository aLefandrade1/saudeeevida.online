import React from 'react';
import { ChefHat } from 'lucide-react';
import type { FormData } from '../types';

interface RecipeFormProps {
  onSubmit: (data: FormData) => void;
}

const RecipeForm: React.FC<RecipeFormProps> = ({ onSubmit }) => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onSubmit({
      name: formData.get('name') as string,
      age: parseInt(formData.get('age') as string),
      weight: parseInt(formData.get('weight') as string),
      goal: formData.get('goal') as string,
    });
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <div 
        className="rounded-lg bg-white shadow-xl p-6 mt-10"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1495195134817-aeb325a55b65?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="bg-white/90 p-6 rounded-lg">
          <div className="flex items-center justify-center mb-6">
            <ChefHat className="w-8 h-8 text-emerald-600" />
            <h1 className="text-2xl font-bold text-emerald-800 ml-2">Receita Personalizada</h1>
          </div>
          
          <p className="text-gray-700 mb-6 text-center">
            Vamos criar uma receita especialmente para você! Preencha os dados abaixo.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Nome
              </label>
              <input
                type="text"
                name="name"
                id="name"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label htmlFor="age" className="block text-sm font-medium text-gray-700">
                Idade
              </label>
              <input
                type="number"
                name="age"
                id="age"
                required
                min="1"
                max="120"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
                Peso (kg)
              </label>
              <input
                type="number"
                name="weight"
                id="weight"
                required
                min="1"
                max="300"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
                Objetivo
              </label>
              <select
                name="goal"
                id="goal"
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              >
                <option value="">Selecione um objetivo</option>
                <option value="Controlar Diabetes">Controlar Diabetes</option>
                <option value="Perder Peso">Perder Peso</option>
                <option value="Ganhar Massa">Ganhar Massa</option>
                <option value="Alimentação Saudável">Alimentação Saudável</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-colors"
            >
              Gerar Receita Personalizada
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RecipeForm;