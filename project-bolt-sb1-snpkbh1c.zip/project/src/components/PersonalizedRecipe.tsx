import React from 'react';
import { ArrowLeft, Download, Utensils } from 'lucide-react';
import type { FormData } from '../types';

interface PersonalizedRecipeProps {
  data: FormData;
  onReset: () => void;
}

const PersonalizedRecipe: React.FC<PersonalizedRecipeProps> = ({ data, onReset }) => {
  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-xl mt-10 overflow-hidden">
        <div 
          className="h-40 bg-cover bg-center relative"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80")',
          }}
        >
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <h1 className="text-3xl font-bold text-white text-center px-4">
              Sua Receita Personalizada
            </h1>
          </div>
        </div>

        <div className="p-6">
          <div className="bg-emerald-50 rounded-lg p-4 mb-6">
            <p className="text-emerald-800">
              <span className="font-bold">{data.name}</span>, você tem{' '}
              <span className="font-bold">{data.age}</span> anos, pesa{' '}
              <span className="font-bold">{data.weight}kg</span> e seu objetivo é{' '}
              <span className="font-bold">{data.goal}</span>. 
              Aqui está sua receita personalizada!
            </p>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 flex items-center">
                <Utensils className="w-6 h-6 mr-2" />
                Bowl de Quinoa com Legumes
              </h2>
              <p className="text-gray-600 mt-2">
                Uma refeição nutritiva e balanceada, perfeita para seu objetivo de {data.goal.toLowerCase()}.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Ingredientes</h3>
              <ul className="list-disc list-inside space-y-1 text-gray-700">
                <li>1 xícara de quinoa</li>
                <li>2 xícaras de água</li>
                <li>1 abobrinha média cortada em cubos</li>
                <li>1 cenoura média ralada</li>
                <li>1 pimentão vermelho picado</li>
                <li>1/2 cebola roxa picada</li>
                <li>2 colheres de sopa de azeite de oliva</li>
                <li>Sal e pimenta a gosto</li>
                <li>Salsinha picada a gosto</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Modo de Preparo</h3>
              <ol className="list-decimal list-inside space-y-2 text-gray-700">
                <li>Lave bem a quinoa em água corrente.</li>
                <li>Em uma panela, cozinhe a quinoa com a água por cerca de 15-20 minutos.</li>
                <li>Enquanto isso, refogue a cebola no azeite até ficar transparente.</li>
                <li>Adicione os legumes e refogue por mais 5 minutos.</li>
                <li>Misture a quinoa cozida com os legumes.</li>
                <li>Tempere com sal e pimenta.</li>
                <li>Finalize com salsinha picada.</li>
              </ol>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <button
              onClick={onReset}
              className="flex-1 flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Início
            </button>
            <button
              onClick={() => window.print()}
              className="flex-1 flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
            >
              <Download className="w-4 h-4 mr-2" />
              Baixar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalizedRecipe;