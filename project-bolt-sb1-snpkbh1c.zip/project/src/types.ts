export interface FormData {
  name: string;
  age: number;
  weight: number;
  goal: string;
}